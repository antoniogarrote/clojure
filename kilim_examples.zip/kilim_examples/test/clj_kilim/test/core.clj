(ns clj-kilim.test.core
  (:use [clj-kilim.core])
  (:use [clojure.test]))

(deftest replace-me ;; FIXME: write
  (is false "No tests have been written."))
