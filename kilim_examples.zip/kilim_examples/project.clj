(defproject clj-kilim "1.0.0-SNAPSHOT"
  :description "FIXME: write description"
  :dependencies [[org.clojure/clojure "1.2.1"]]
  :dev-dependencies [[swank-clojure "1.3.0-SNAPSHOT"]])
